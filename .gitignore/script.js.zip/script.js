// Pseudo Code Project 3 - Emma Fattori

// MVP: Create an interactive children's story. 

// Step 1: On homepage, user will enter their first name as a text input and their pronouns from radio buttons. 
// Step 1a: Save these inputs as variables for later use in the <p> tags.

// Step 2: On homepage, user will click on "start story" to bring them to the next section of the story.

// Step 3: Smooth scroll will bring the user to the next section of the story.

// Step 4: In the 'story' sections, user will have two options. #1 - to animate the cartoon on mouse enter/mouse leave. #2 - to click "Continue Reading Story" which will bring the user to the next story section. 


// Step 5: On the last section, provide a CTA to user. CTA will have an anchor tag informing user to click if they would like to learn more about bugs. This will bring the user to the Cambridge butterfly conservatory.
// Step 5a: User can click on CTA to bring them to the beginning of the story again.


// Stretch Goals: 1. Adding personal illustrations. 2. Using impress.js to present the story. 3. Adding elements of education, such as flipping over a card and having the reader guess what will happen next. 4. Using a more modular approach for a 'pick your own ending' type of experience.


